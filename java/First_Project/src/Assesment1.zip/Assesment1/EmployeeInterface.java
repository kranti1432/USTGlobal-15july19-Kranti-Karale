package Assesment1;

public interface EmployeeInterface {
	public boolean addEmployee(String s,Employee e);
	public boolean removeEmployee(Employee e);
	public boolean searchKeyEmployee(String s);
	public boolean searchValueEmployee(Employee e);
	boolean grade(String s, Employee e);
}
